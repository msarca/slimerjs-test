let { deprecateUsage } = require("../util/deprecate");

deprecateUsage("Module 'sdk/page-mod/match-pattern' is deprecated use 'sdk/util/match-pattern' instead");

module.exports = require("../util/match-pattern");
